import encryption,googleDriveAPI,users,sys
usr,encr,googleAPI= users,encryption,googleDriveAPI
def menu():
    try:
        while True:
            Input_from_user = input("\nupload - Uploading file , download - Download file, logout - Log Out , exit - Exit\n").lower()
            if(Input_from_user == "upload"):
                while True:
                    print("\nEnsure that files you wish to upload are in the 'F' folder.Enter return to return to main menu\n")
                    Input_from_user = input("Enter file name: ")
                    if(Input_from_user == "return"):
                        break
                    else:
                       encr.encrypt(Input_from_user, encr.read_keys())
                       googleAPI.u_File(Input_from_user)

            elif(Input_from_user == "exit"):
                print("Exit")
                sys.exit()

            elif(Input_from_user == "logout"):
                print("Log out")
                break

            elif(Input_from_user == "download"):
                while True:
                    Input_from_user = input("\nsearch - Searching file , download - downloading File ,exit - Exit\n").lower()
                    if(Input_from_user == "search"):
                        Input_from_user = input("Enter file name: ")
                        googleAPI.s_File(Input_from_user)
                    elif(Input_from_user == "download"):
                        Input_from_user = input("Enter file name: ")
                        fileID= googleAPI.f_ID(Input_from_user)
                        googleAPI.d_File(fileID, Input_from_user)
                        encr.decrypt(Input_from_user, encr.read_keys())
                    elif(Input_from_user == "exit"):
                        break
                    else:
                        print("Wrong input try again")
            else:
                 print("Wrong input try again")
    except Exception:
        pass

def special_Menu():
    try:
        while True:
            user_In = input("\nupload - Uploading file , download - Download file,usersettings -For User Setting, logout - Log Out , exit - Exit\n").lower()
            if(user_In == "usersettings"):
                while True:
                    user_In = input("\nadd - Add User , delete - Delete User , exit - Exit\n").lower()
                    if (user_In == "add"):
                        usr.add_user()
                    elif(user_In == "delete"):
                        usr.delete_user()
                    elif(user_In == "exit"):
                        break
                    else:
                        print("Wrong input try again")

            elif(user_In == "upload"):
                while True:
                    print("\nEnsure that files you wish to upload are in the 'F' folder. \nEnter return to return to main menu.\n")
                    user_In = input("Enter file name: ")
                    if(user_In == "return"):
                        break
                    else:
                       encr.encrypt(user_In, encr.read_keys())
                       googleAPI.u_File(user_In)

            elif(user_In == "exit"):
                print("Exit")
                sys.exit()
            elif(user_In == "logout"):
                usr.flg = False
                print("Log out")
                break
            elif(user_In == "download"):
                while True:
                    user_In = input("\nsearch - Searching for file , download - Downloading File , exit - Exit\n").lower()
                    if(user_In == "search"):
                        user_In = input("Enter file name: ")
                        googleAPI.s_File(user_In)
                    elif(user_In == "download"):
                        user_In = input("Enter file name: ")
                        fileID= googleAPI.fileID(user_In)
                        googleAPI.d_File(fileID, user_In)
                        encr.decrypt(user_In, encr.keyRead())
                    elif(user_In == "exit"):
                        break
                    else:
                        print("Wrong input try again")
            else:
                 print("Wrong input try again")

    except Exception:
        pass
