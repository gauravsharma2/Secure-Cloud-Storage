import pickle
import sys
import getpass

def loading_array(usr):
    try:
        with open('Usr/' + usr + '.pkl', 'rb') as f:
          return pickle.load(f)
    except Exception:
          pass

usr = loading_array("list")

flg = False
if not usr:
    acc = 0
else:
    acc = 1

def store_list(o, usr ):
    with open('Usr/'+ usr + '.pkl', 'wb') as f:
        pickle.dump(o, f, pickle.HIGHEST_PROTOCOL)

def add_user():   
    while True:
        usr_input = input("Create login name:")
        if usr_input in usr:
            print("Login name already exists!")
        else:
            pass_ = getpass.getpass("Create password:")
            usr[usr_input] = pass_
            store_list(usr, "list")
            print("User created")
            break

def delete_user():
    u_name = input("Enter username for deletion:")
    if u_name == "admin":
        print("Cannot delete the admin account.")
    elif u_name in usr:
        del usr[u_name]
        store_list(usr, "list")
        print("User deleted.")
    else:
        print("User name does not exists!")
        
def login():
    global flg
    cnt = 0
    while True:
        _input = input("Enter login:")
        _pass = getpass.getpass("Enter password:")
        if _input in usr and usr[_input] == _pass and _input == "admin":
            flg = True
            print("Login successful!")
            break
        elif _input in usr and usr[_input] == _pass:
            print("Login successful!")
            break
        else:
            cnt = cnt+1
            print("Usr doesn't exist or wrong password!")
