from __future__ import print_function
import httplib2
import os

from apiclient import discovery
from oauth2client import client
from oauth2client import tools
from oauth2client.file import Storage

try:
    import argparse
    flags = argparse.ArgumentParser(parents=[tools.argparser]).parse_args()
except ImportError:
    flags = None
import io
import auth
from apiclient.http import MediaFileUpload, MediaIoBaseDownload

SCOPES = 'https://www.googleapis.com/auth/drive'
CLIENT_SECRET_FILE = 'client_secret.json'
APPLICATION_NAME = 'Drive API Python Quickstart'

authIntsance = auth.auth(SCOPES,CLIENT_SECRET_FILE,APPLICATION_NAME)
credentials  =authIntsance.get_credentials()
http = credentials.authorize(httplib2.Http())
service = discovery.build('drive', 'v3', http=http)

def d_File(f_id, f_Name):
    try:
        req = service.files().get_media(fileId=f_id)
        f_io_byte = io.BytesIO()
        media_load = MediaIoBaseDownload(f_io_byte, req)
        flag = False
        while flag is False:
            status, flag = media_load.next_chunk()
            print("Download %d%%." % int(status.progress() * 100))
        with io.open("download/" + f_Name, 'wb') as f:
            f_io_byte.seek(0)
            f.write(f_io_byte.read())
    except Exception:
        print("File does not exists")

def u_File(f_Name):
    try:
        f_metadata = {'name': f_Name}
        f_path = "F/"+f_Name
        m_upload = MediaFileUpload(f_path,
                                mimetype="text/plain")
        f = service.files().create(body=f_metadata,
                                            media_body=m_upload,
                                            fields='id').execute()
        f_id = f.get('id')
        print('File ID:' + f_id )
    except Exception:
        print("File does not exists")

def f_ID(q):
    res = service.files().list(
    pageSize=100,fields="nextPageToken, files(id, name)", q="name contains '" + q +"'").execute()
    itm = res.get('files', [])
    if not itm:
        print('No files found.')
    else:
        for i in itm:
            return i['id']

def s_File(q):
    res = service.files().list(
    pageSize=100,fields="nextPageToken, files(id, name)", q="name contains '" + q +"'").execute()
    itm = res.get('files', [])
    if not itm:
        print('No files found.')
    else:
        for item in itm:
            print(item['name'])