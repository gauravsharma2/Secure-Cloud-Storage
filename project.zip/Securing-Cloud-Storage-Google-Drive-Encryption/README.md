Cloud-Storage-Google-Drive-Encryption

In order to run the python code run the following commands:
1. pip install encryption
2. pip install oauth2client
3. py main.py


