import io
from cryptography.fernet import Fernet

def k_gen():
    key = Fernet.generate_key()
    file = open('k/key.key', 'wb')
    file.write(key)
    file.close()

def read_keys():
    try:
        file = open('k/key.key', 'rb')
        key = file.read()
        file.close()
        return key
    except Exception:
        print("No Key exists")
        k_gen()
        read_keys()

def decrypt(f_Name, Key):
    with open("download/"+ f_Name, "rb") as f:
        data = f.read()
    fernet = Fernet(Key)
    decrypt_message = fernet.decrypt(data)
    with open("download/"+ f_Name, "wb") as f:
        f.write(decrypt_message)

def encrypt(f_Name, Key):
    with open("F/"+ f_Name, "rb") as f:
        data = f.read()
    fernet = Fernet(Key)
    encrypt_message = fernet.encrypt(data)
    with open("F/"+ f_Name, "wb") as f:
        f.write(encrypt_message)

