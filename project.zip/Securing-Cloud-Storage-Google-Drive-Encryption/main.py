import encryption
import googleDriveAPI
from googleapiclient import *
import users
import card

def main():
    encrypt = encryption
    key = encrypt.read_keys()
    try:
        while True:
            usr = users
            crd = card
            if(usr.acc == 0):
                print("You must create an admin account.\n")
                usr.add_user()
            else:
                usr.login()
                if usr.flg:
                    crd.special_Menu()
                else:
                    crd.menu()
    except Exception:
        pass

if __name__ == "__main__":
   main()